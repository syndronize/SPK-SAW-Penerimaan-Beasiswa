@include('backend.includes.header')
@include('backend.includes.sidebar')
<main>
@yield('content')
</main>
@include('backend.includes.footer')
