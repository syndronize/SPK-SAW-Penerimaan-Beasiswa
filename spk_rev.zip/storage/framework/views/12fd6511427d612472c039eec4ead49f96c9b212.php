<?php $__env->startSection('content'); ?>
<title>Admin</title>
<div class="container-fluid px-4">
        <h1 class="mt-4">Admin</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Data Admin
                <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-success mb-2">Tambah Data</a>
            </div>
            <div class="card-body">
                <table id="datatablesSimple">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>No. HP</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($no + 1); ?></td>
                                <td><?php echo e($admin->nama_admin); ?></td>
                                <td><?php echo e($admin->username_admin); ?></td>
                                <td><?php echo e($admin->nohp_admin); ?></td>
                                <td align="center">
                                    <a href="<?php echo e(route('admin.edit', $admin->id_admin)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> </a>
                                    <a href="<?php echo e(route('admin.delete', $admin->id_admin)); ?>" class="btn btn-danger btn-sm" onclick="mHapus('<?php echo e(route('admin.delete', $admin->id_admin)); ?>')"><i class="fa fa-trash"></i> </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\spk_rev\resources\views/backend/pages/admin/index.blade.php ENDPATH**/ ?>