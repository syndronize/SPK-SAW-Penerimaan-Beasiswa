<?php $__env->startSection('content'); ?>
<title>Form Murid</title>
<div class="container-fluid px-4">
    <h1 class="mt-4"></h1>
    <div class="card mb-4">
        <div class="card-header">
            <h3 class="text-center font-weight-light my-4">Form Murid</h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(isset($murid) ? route('murid.update', $murid->id_murid) : route('murid.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if(isset($murid)): ?>
                <?php echo method_field('put'); ?>
            <?php endif; ?>
                <div class="form-floating mb-3">
                    <input class="form-control  <?php $__errorArgs = ['nama_murid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_murid" type="text"
                    value="<?php echo e(old('nama_murid') ?? $murid->nama_murid ?? ''); ?>"/>
                    <label for="nama_murid">Nama Lengkap</label>
                </div>
                <div class="form-floating mb-3">
                    <input class="form-control <?php $__errorArgs = ['nisn_murid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nisn_murid" type="text" value="<?php echo e(old('nisn_murid') ?? $murid->nisn_murid ?? ''); ?>"/>
                    <label for="nisn_murid">NISN</label>
                </div>
                <div class="mb-3">
                <select name="jk_murid" id="jk_murid" class="form-select" aria-label="Default select example">Jenis Kelamin
                <option value="" disabled select selected>-Pilih Jenis Kelamin-</option>
                <option value="Laki-Laki">Laki-Laki</option>
                <option value="Perempuan">Perempuan</option>
                </select>
                </div>
                <div class="form-floating mb-3">
                    <input class="form-control <?php $__errorArgs = ['kelas_murid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="kelas_murid" type="text" value="<?php echo e(old('kelas_murid') ?? $murid->kelas_murid ?? ''); ?>"/>
                    <label for="kelas_murid">Kelas</label>
                </div>
                <div class="form-floating mb-3">
                    <input class="form-control <?php $__errorArgs = ['nohp_murid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php echo e('is-invalid'); ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nohp_murid" type="text"
                    value="<?php echo e(old('nohp_murid') ?? $murid->nohp_murid ?? '+62'); ?>"/>
                    <label for="nohp_murid">No. HP</label>
                </div>
                <div>
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-check-circle"></i>Submit</button>
                    <button type="reset" class="btn btn-danger btn-sm"><i class="fa fa-eraser"></i> Reset</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\spk_rev\resources\views/backend/pages/murid/form.blade.php ENDPATH**/ ?>