<?php $__env->startSection('content'); ?>
<title>Home</title>
<div class="container-fluid px-4">
    <h1 class="mt-4">Ranking</h1>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Rangking Penerimaan Beasiswa
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Ranking</th>
                        <th>Nama</th>
                        <th>NISN</th>
                        <th>Kelas</th>
                        <th>Poin</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="1%"><?php echo e($no + 1); ?></td>
                        <td><?php echo e($kriteria->nama_murid); ?></td>
                        <td><?php echo e($kriteria->nisn_murid); ?></td>
                        <td><?php echo e($kriteria->kelas_murid); ?></td>
                        <td><?php echo e($kriteria->nilai_akhir_kriteria); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\spk_rev\resources\views/backend/home.blade.php ENDPATH**/ ?>