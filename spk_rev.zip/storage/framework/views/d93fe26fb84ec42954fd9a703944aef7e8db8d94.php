<?php $__env->startSection('content'); ?>
<title>Kriteria</title>
<div class="container-fluid px-4">
        <h1 class="mt-4">Kriteria</h1>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Data Kriteria
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Nama Murid</th>
                        <th>Jumlah Tanggungan Orang Tua</th>
                        <th>Pendapatan Orang Tua</th>
                        <th>Rata Rata Nilai Murid</th>
                        <th>Penggunaan Transportasi</th>
                        <th>Nilai Akhir</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kriteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$kriteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no + 1); ?></td>
                            <td><?php echo e($kriteria->nama_murid); ?></td>
                            <td><?php echo e($kriteria->tanggungan_kriteria); ?></td>
                            <td><?php echo e($kriteria->pendapatan_kriteria); ?></td>
                            <td><?php echo e($kriteria->rata_kriteria); ?></td>
                            <td><?php echo e($kriteria->transportasi_kriteria); ?></td>
                            <td><?php echo e($kriteria->nilai_akhir_kriteria); ?></td>
                            <td align="center" width="10%">
                                <a href="<?php echo e(route('kriteria.edit', $kriteria->id_kriteria)); ?>" class="btn btn-warning btn-sm"><i class="fas fa-edit"></i> </a>
                                <a href="<?php echo e(route('kriteria.delete', $kriteria->id_kriteria)); ?>" class="btn btn-danger btn-sm" onclick="mHapus('<?php echo e(route('kriteria.delete', $kriteria->id_kriteria)); ?>')"><i class="fa fa-trash"></i> </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\spk_rev\resources\views/backend/pages/kriteria/index.blade.php ENDPATH**/ ?>